import data from './data.json';

export const vehiclesData = data.vehicles;
export const locationsData = data.locations;

export const reviewsData = data["customer-reviews"];